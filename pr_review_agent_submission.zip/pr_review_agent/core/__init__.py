"""Core functionality for the PR Review Agent."""
