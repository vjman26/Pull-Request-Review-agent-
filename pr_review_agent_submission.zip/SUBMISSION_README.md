# PR Review Agent - CodeMate Submission

## Quick Start

### Method 1: Web Application (Recommended)
```bash
python deploy.py
```
Then open http://localhost:5000 in your browser

### Method 2: Direct Flask
```bash
python app.py
```

### Method 3: Desktop GUI
```bash
python pr_review_gui_enhanced.py
```

## Project Structure

- app.py - Main Flask web application
- pr_review_agent/ - Core Python package
- templates/ - Web UI templates
- static/ - CSS and JavaScript files
- examples/ - Usage examples
- tests/ - Test suite

## Features

- Multi-server support (GitHub, GitLab, Bitbucket)
- Code quality analysis
- Security vulnerability detection
- AI-powered suggestions
- Web interface and desktop GUI
- Export reports
- Analysis history

## How to Use

1. Run the web application
2. Paste your Python code
3. Click "Analyze Code"
4. View results and suggestions

## Analysis Capabilities

- Code quality scoring (0-10)
- Issue detection and categorization
- Security vulnerability scanning
- Performance suggestions
- Style and readability checks

This is a complete PR Review Agent implementation with web interface,
desktop GUI, and comprehensive code analysis capabilities.
